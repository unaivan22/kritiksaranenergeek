<?php
$host = 'localhost';
$user = 'eneg1777_kritik_saran_db';
$password = 'kritik_saran';
$dbname = 'eneg1777_kritik_saran_db';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

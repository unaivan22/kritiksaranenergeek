<?php
include 'config.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$data = json_decode(file_get_contents("php://input"), true);

if (!empty($data['recipient']) && !empty($data['message'])) {
    $stmt = $conn->prepare("INSERT INTO kritik_saran (recipient, message) VALUES (?, ?)");
    $stmt->bind_param("ss", $data['recipient'], $data['message']);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Kritik & Saran berhasil dikirim"]);
    } else {
        echo json_encode(["error" => "Gagal mengirim"]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "Data tidak lengkap"]);
}

$conn->close();
?>

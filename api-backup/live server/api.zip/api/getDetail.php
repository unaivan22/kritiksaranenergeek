<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
include 'config.php'; // Koneksi ke database

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM kritik_saran WHERE id='$id'");

if ($row = mysqli_fetch_assoc($result)) {
    // Format tanggal sebelum dikirim ke frontend
    $row['created_at'] = date("M j, Y", strtotime($row['created_at']));
    
    echo json_encode($row);
} else {
    echo json_encode(["error" => "Data not found"]);
}
?>
